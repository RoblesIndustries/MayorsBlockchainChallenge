# qrcode-generator
QR Code Generator implementation in JavaScript, Java and more

[online demo(js)](https://kazuhikoarase.github.io/qrcode-generator/js/demo/)

The word "QR Code" is registered trademark of DENSO WAVE INCORPORATED
<br/>http://www.denso-wave.com/qrcode/faqpatent-e.html
